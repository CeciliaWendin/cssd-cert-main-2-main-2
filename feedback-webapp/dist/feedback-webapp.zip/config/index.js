"use strict";

(function () {
  var router = require("router");
  router.get("/", function (req, res) {
    res.render({});
  });
})();